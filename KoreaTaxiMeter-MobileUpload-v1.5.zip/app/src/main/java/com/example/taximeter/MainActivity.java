package com.example.taximeter;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    TextView fare, dist, speed, gps, gap, distanceTitle, distanceRemain, timeTitle, timeRemain, mode;
    ProgressBar distanceBar, timeBar;
    Button start, stop, settings;

    private final BroadcastReceiver meterReceiver = new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){
            if(!"METER_UPDATE".equals(i.getAction())) return;
            fare.setText(String.format(Locale.KOREA,"%,d 원",i.getIntExtra("fare",0)));
            dist.setText(String.format(Locale.KOREA,"주행거리 %.2f km",i.getDoubleExtra("distance",0)));
            speed.setText(String.format(Locale.KOREA,"속도 %.1f km/h",i.getDoubleExtra("speed",0)));
            gps.setText(i.getStringExtra("gps"));
            gap.setText(String.format(Locale.KOREA,"GPS 보정거리 %.2f km",i.getDoubleExtra("gap",0)));

            boolean basePhase=i.getBooleanExtra("basePhase",false);
            int dRemain=i.getIntExtra("distanceRemain",0), dMax=i.getIntExtra("distanceMax",1), dProgress=i.getIntExtra("distanceProgress",0);
            if(basePhase){
                distanceTitle.setText("기본요금 포함거리까지");
                distanceRemain.setText(String.format(Locale.KOREA,"%d m",dRemain));
            }else{
                distanceTitle.setText("다음 거리요금까지");
                distanceRemain.setText(String.format(Locale.KOREA,"%d m",dRemain));
            }
            distanceBar.setMax(Math.max(1,dMax)); distanceBar.setProgress(Math.min(dMax,Math.max(0,dProgress)));

            boolean timeActive=i.getBooleanExtra("timeActive",false);
            int tRemain=i.getIntExtra("timeRemain",0), tMax=i.getIntExtra("timeMax",30), tProgress=i.getIntExtra("timeProgress",0);
            timeTitle.setText(timeActive ? "다음 시간요금까지 · 시간·거리 동시병산" : "시간요금 병산 대기");
            timeRemain.setText(timeActive ? String.format(Locale.KOREA,"%d 초",tRemain) : "—");
            timeBar.setMax(Math.max(1,tMax)); timeBar.setProgress(timeActive ? Math.min(tMax,Math.max(0,tProgress)) : 0);
            mode.setText(timeActive ? "● 시간·거리 동시병산 중" : "● 거리 병산 중");
        }
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22,16,22,12); root.setBackgroundColor(Color.WHITE);
        ScrollView scroll=new ScrollView(this);
        LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(0,0,0,8);
        scroll.addView(content);

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=t("Korea Taxi Meter 1.5",23); top.addView(title,new LinearLayout.LayoutParams(0,dp(54),1));
        settings=new Button(this); settings.setText("⚙ 요금 설정"); settings.setMinHeight(dp(50)); top.addView(settings,new LinearLayout.LayoutParams(-2,dp(54))); content.addView(top);

        fare=t("4,800 원",62); fare.setGravity(Gravity.CENTER); fare.setTypeface(null,android.graphics.Typeface.BOLD); fare.setPadding(0,8,0,8);
        content.addView(fare,new LinearLayout.LayoutParams(-1,dp(145)));

        mode=t("● 거리 병산 중",15); mode.setGravity(Gravity.CENTER); content.addView(mode,new LinearLayout.LayoutParams(-1,dp(28)));

        LinearLayout dBox=box();
        distanceTitle=t("기본요금 포함거리까지",15); distanceTitle.setGravity(Gravity.CENTER);
        distanceRemain=t("1,600 m",34); distanceRemain.setGravity(Gravity.CENTER); distanceRemain.setTypeface(null,android.graphics.Typeface.BOLD);
        distanceBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); distanceBar.setMax(1600); distanceBar.setProgress(0);
        dBox.addView(distanceTitle); dBox.addView(distanceRemain,new LinearLayout.LayoutParams(-1,dp(48))); dBox.addView(distanceBar,new LinearLayout.LayoutParams(-1,dp(20)));
        content.addView(dBox,new LinearLayout.LayoutParams(-1,dp(120)));

        LinearLayout tBox=box();
        timeTitle=t("시간요금 병산 대기",15); timeTitle.setGravity(Gravity.CENTER);
        timeRemain=t("—",34); timeRemain.setGravity(Gravity.CENTER); timeRemain.setTypeface(null,android.graphics.Typeface.BOLD);
        timeBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); timeBar.setMax(30); timeBar.setProgress(0);
        tBox.addView(timeTitle); tBox.addView(timeRemain,new LinearLayout.LayoutParams(-1,dp(48))); tBox.addView(timeBar,new LinearLayout.LayoutParams(-1,dp(20)));
        content.addView(tBox,new LinearLayout.LayoutParams(-1,dp(120)));

        dist=t("주행거리 0.00 km",17); speed=t("속도 0.0 km/h",17); gps=t("GPS 대기",14); gap=t("GPS 보정거리 0.00 km",14);
        content.addView(dist); content.addView(speed); content.addView(gps); content.addView(gap);

        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); buttons.setPadding(0,8,0,4);
        start=new Button(this); start.setText("운행 시작"); stop=new Button(this); stop.setText("운행 종료");
        start.setTextSize(18); stop.setTextSize(18); start.setMinHeight(dp(62)); stop.setMinHeight(dp(62));
        buttons.addView(start,new LinearLayout.LayoutParams(0,dp(68),1)); buttons.addView(stop,new LinearLayout.LayoutParams(0,dp(68),1)); content.addView(buttons);

        TextView note=t("실제 택시미터기처럼 다음 요금까지 남은 거리·시간을 카운트합니다. 0에 도달하면 요금이 증가하고 카운터가 다시 시작됩니다.",12); note.setPadding(0,8,0,8); content.addView(note);

        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);

        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},10);
        settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        start.setOnClickListener(v->{ if(Build.VERSION.SDK_INT>=26) startForegroundService(new Intent(this,MeterService.class)); else startService(new Intent(this,MeterService.class)); });
        stop.setOnClickListener(v->stopService(new Intent(this,MeterService.class)));
        IntentFilter f=new IntentFilter("METER_UPDATE");
        if(Build.VERSION.SDK_INT>=33) registerReceiver(meterReceiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(meterReceiver,f);
    }

    LinearLayout box(){
        LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setPadding(12,8,12,8); b.setBackgroundColor(Color.rgb(245,245,245)); return b;
    }
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(Color.BLACK);v.setPadding(0,4,0,4);return v;}
    @Override protected void onDestroy(){try{unregisterReceiver(meterReceiver);}catch(Exception ignored){} super.onDestroy();}
}
