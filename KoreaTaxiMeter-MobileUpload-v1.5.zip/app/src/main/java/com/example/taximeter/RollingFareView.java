package com.example.taximeter;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/** A simple taxi-meter-style rolling number display. */
public class RollingFareView extends LinearLayout {
    private int currentValue = Integer.MIN_VALUE;
    private final LinearLayout digits = this;
    private int textSizeSp = 52;

    public RollingFareView(Context c) { super(c); init(); }
    public RollingFareView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER);
        setClipChildren(true);
        setClipToPadding(true);
    }

    public void setFare(int value, boolean animate) {
        value = Math.max(0, value);
        if (value == currentValue) return;
        String next = String.format(Locale.KOREA, "%,d", value);
        if (!animate || currentValue == Integer.MIN_VALUE) {
            removeAllViews();
            for (char ch : next.toCharArray()) addStatic(ch);
            addWon();
            currentValue = value;
            return;
        }
        String old = String.format(Locale.KOREA, "%,d", Math.max(0, currentValue));
        if (old.length() != next.length()) {
            removeAllViews();
            for (char ch : next.toCharArray()) addAnimated(ch, true);
            addWon();
        } else {
            removeAllViews();
            for (int i = 0; i < next.length(); i++) {
                char a = old.charAt(i), b = next.charAt(i);
                if (a == b || !Character.isDigit(a) || !Character.isDigit(b)) addStatic(b);
                else addAnimated(b, true);
            }
            addWon();
        }
        currentValue = value;
    }

    private void addStatic(char ch) {
        TextView v = makeText(ch);
        addView(v);
    }

    private void addAnimated(char ch, boolean roll) {
        TextView v = makeText(ch);
        if (roll) {
            v.setTranslationY(-getResources().getDisplayMetrics().density * 48f);
            v.setAlpha(0.15f);
            v.animate().translationY(0).alpha(1f).setDuration(190)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
        addView(v);
    }

    private void addWon() {
        TextView v = makeText('원');
        v.setTextSize(28);
        v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        LayoutParams lp = new LayoutParams((int)(48 * getResources().getDisplayMetrics().density + 0.5f), -1);
        v.setLayoutParams(lp);
        addView(v);
    }

    private TextView makeText(char ch) {
        TextView v = new TextView(getContext());
        v.setText(String.valueOf(ch));
        v.setTextSize(textSizeSp);
        v.setTextColor(Color.BLACK);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        v.setIncludeFontPadding(false);
        int w = ch == ',' ? 24 : 42;
        int d = (int)(w * getResources().getDisplayMetrics().density + 0.5f);
        LayoutParams lp = new LayoutParams(d, -1);
        v.setLayoutParams(lp);
        return v;
    }
}
