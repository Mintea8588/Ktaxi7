package com.example.taximeter;

import android.app.*;
import android.content.*;
import android.location.Location;
import android.os.*;
import androidx.annotation.NonNull;
import com.google.android.gms.location.*;
import java.util.*;

public class MeterService extends Service {
    private FusedLocationProviderClient client;
    private Location last;
    private long gapStart = 0, lastTick = 0;
    private double total = 0, gapDistance = 0;
    private float lastSpeed = 0;
    private long lowSeconds = 0;
    private static final double MIN_GAP = 10.0, MAX_GAP_SEC = 180.0, MAX_GAP_DISTANCE = 5000.0;

    private final LocationCallback cb = new LocationCallback(){
        @Override public void onLocationResult(@NonNull LocationResult r){
            for(Location l:r.getLocations()) handle(l);
        }
    };

    @Override public void onCreate(){
        super.onCreate();
        client = LocationServices.getFusedLocationProviderClient(this);
        startForeground(77, notification("택시미터 운행 중"));
        request();
    }

    private void request(){
        LocationRequest req = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000)
                .setMinUpdateIntervalMillis(500).setMaxUpdateDelayMillis(2000).build();
        try { client.requestLocationUpdates(req,cb,Looper.getMainLooper()); }
        catch(SecurityException e){ stopSelf(); }
    }

    private void handle(Location l){
        long now = System.currentTimeMillis();
        TariffConfig c = new TariffConfig(this);
        float acc = l.hasAccuracy() ? l.getAccuracy() : 999f;

        if(last == null){
            last = l;
            lastTick = now;
            send(l, c);
            return;
        }

        double dt = Math.max(0, (now-lastTick)/1000.0);

        // Poor-quality GPS is treated as a gap. Do not move the reference point
        // until a usable fix returns.
        if(acc > 80f){
            if(gapStart == 0) gapStart = lastTick;
            send(l, c);
            return;
        }

        if(gapStart > 0){
            double gapSec = Math.max(0, (now-gapStart)/1000.0);
            float straight = last.distanceTo(l);
            double expected = Math.max(0, lastSpeed) * gapSec;
            boolean accepted = gapSec <= MAX_GAP_SEC && straight >= MIN_GAP && straight <= MAX_GAP_DISTANCE;
            if(accepted){
                double ratio = expected > 1 ? straight/expected : 1;
                accepted = expected < 1 || (ratio >= 0.35 && ratio <= 2.8);
            }
            if(accepted){
                total += straight;
                gapDistance += straight;
            }
            // For a partial simultaneous meter, low-speed time continues through
            // a short GPS gap using the last reliable speed estimate.
            if(gapSec > 0 && gapSec <= MAX_GAP_SEC && lastSpeed*3.6 < c.lowSpeedKmh()) {
                lowSeconds += Math.round(gapSec);
            }
            gapStart = 0;
        } else {
            float d = last.distanceTo(l);
            if(d >= MIN_GAP && d < 1000 && dt < 15){
                // Distance is always accumulated. At low speed, time is added too.
                // This implements Seoul's partial simultaneous time-distance rule.
                total += d;
            }
            if(lastSpeed*3.6 < c.lowSpeedKmh() && dt > 0 && dt <= 5){
                lowSeconds += Math.round(dt);
            }
        }

        if(l.hasSpeed()) lastSpeed = Math.max(0, l.getSpeed());
        else if(dt > 0 && dt <= 15) lastSpeed = Math.max(0, (float)(last.distanceTo(l)/dt));

        last = l;
        lastTick = now;
        send(l, c);
    }

    private int roundTo(int value, int unit){
        if(unit <= 1) return value;
        return Math.round(value/(float)unit)*unit;
    }

    private int nightPercent(){
        TariffConfig c = new TariffConfig(this);
        if(!c.autoNight()) return 0;
        Calendar now=Calendar.getInstance();
        int h=now.get(Calendar.HOUR_OF_DAY), m=now.get(Calendar.MINUTE), mins=h*60+m;
        // Seoul: 22:00-23:00 and 02:00-04:00 = 20%; 23:00-02:00 = 40%.
        if(mins>=23*60 || mins<2*60) return c.nightPeakPct();
        if(mins>=22*60 || mins<4*60) return c.nightPct();
        return 0;
    }

    private int calcFare(){
        TariffConfig c = new TariffConfig(this);
        int np = nightPercent();

        int base = c.baseFare();
        int df = c.distanceUnitFare();
        int tf = c.timeUnitFare();
        if(np > 0){
            base = roundTo(Math.round(base*(1+np/100f)), 100);
            df = roundTo(Math.round(df*(1+np/100f)), 10);
            tf = roundTo(Math.round(tf*(1+np/100f)), 10);
        }

        double beyond = Math.max(0, total-c.baseDistanceM());
        int fare = base
                + (int)Math.floor(beyond/c.distanceUnitM())*df
                + (int)Math.floor(lowSeconds/(double)c.timeUnitSec())*tf;

        if(c.outOfArea()){
            int extra = Math.min(c.outPct(), Math.max(0, 60-np));
            fare = Math.round(fare*(1+extra/100f));
        }
        // Seoul reports the final meter amount rounded to the nearest 10 won.
        return roundTo(fare,10);
    }

    private void send(Location l, TariffConfig c){
        Intent i=new Intent("METER_UPDATE");
        i.putExtra("fare",calcFare());
        i.putExtra("distance",total/1000);
        i.putExtra("speed",lastSpeed*3.6);
        i.putExtra("gap",gapDistance/1000);

        // Real-meter style countdown: show the remaining distance/time until the next fare increment.
        double beyond = Math.max(0, total - c.baseDistanceM());
        boolean basePhase = total < c.baseDistanceM();
        int dMax = basePhase ? c.baseDistanceM() : Math.max(1, c.distanceUnitM());
        int dProgress = basePhase ? (int)Math.min(c.baseDistanceM(), Math.floor(total)) : (int)Math.floor(beyond % c.distanceUnitM());
        int dRemain = Math.max(0, dMax - dProgress);
        if(dRemain == 0) dRemain = dMax;
        i.putExtra("basePhase", basePhase);
        i.putExtra("distanceRemain", dRemain);
        i.putExtra("distanceMax", dMax);
        i.putExtra("distanceProgress", dMax - dRemain);

        boolean timeActive = lastSpeed * 3.6 < c.lowSpeedKmh();
        int tMax = Math.max(1, c.timeUnitSec());
        int tProgress = (int)Math.floor(lowSeconds % tMax);
        int tRemain = Math.max(0, tMax - tProgress);
        if(tRemain == 0) tRemain = tMax;
        i.putExtra("timeActive", timeActive);
        i.putExtra("timeRemain", tRemain);
        i.putExtra("timeMax", tMax);
        i.putExtra("timeProgress", tMax - tRemain);
        String status = l.hasAccuracy() && l.getAccuracy()<=80 ? "GPS 정상" : "GPS 신호 불량 · 보정 대기";
        i.putExtra("gps", status+" · ±"+(int)(l.hasAccuracy()?l.getAccuracy():0)+" m");
        sendBroadcast(i);
    }

    private Notification notification(String s){
        String ch="meter";
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"Taxi Meter",NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this,ch).setContentTitle("Korea Taxi Meter").setContentText(s).setSmallIcon(android.R.drawable.ic_menu_mylocation).build();
    }
    @Override public void onDestroy(){client.removeLocationUpdates(cb);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
